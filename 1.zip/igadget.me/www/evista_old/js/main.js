$(window).load(function() {
    $('.leoslider').leoslider({
      animation: "slide"
    });
});